first (nieprawda, cos tam krecilem z git'em i usunelo mi wszystkie pliki i commity z github'u ktore byly tu od kilku tygodni, az szkoda gadac) commit

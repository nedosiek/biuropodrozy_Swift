public class Concert {
    /*public static double artist_play_concert(){
        Fight.comparison();
        return
    }*/
}
